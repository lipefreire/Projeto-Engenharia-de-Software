package com.mycompany.estudodecaso;

public class Estudo {
    private String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    private String dataEmissaoProtocolo;
    private String dataInicioExperimento;
    private String dataFimExperimento;
    private String justificativaUsoAnimais;
    private String resumoPortugues;
    private String resumoIngles;
    private String dataEnvioParecer;
    private String dataEmissaoParecer;
    private String descricaoParecer;
    private String statusParecer;
    private String dataDeliberacaoProtocolo;
    private String statusDeliberacao;
    private String statusProtocolo;

    public String getDataEmissaoProtocolo() {
        return dataEmissaoProtocolo;
    }

    public void setDataEmissaoProtocolo(String dataEmissaoProtocolo) {
        this.dataEmissaoProtocolo = dataEmissaoProtocolo;
    }

    public String getDataInicioExperimento() {
        return dataInicioExperimento;
    }

    public void setDataInicioExperimento(String dataInicioExperimento) {
        this.dataInicioExperimento = dataInicioExperimento;
    }

    public String getDataFimExperimento() {
        return dataFimExperimento;
    }

    public void setDataFimExperimento(String dataFimExperimento) {
        this.dataFimExperimento = dataFimExperimento;
    }

    public String getJustificativaUsoAnimais() {
        return justificativaUsoAnimais;
    }

    public void setJustificativaUsoAnimais(String justificativaUsoAnimais) {
        this.justificativaUsoAnimais = justificativaUsoAnimais;
    }

    public String getResumoPortugues() {
        return resumoPortugues;
    }

    public void setResumoPortugues(String resumoPortugues) {
        this.resumoPortugues = resumoPortugues;
    }

    public String getResumoIngles() {
        return resumoIngles;
    }

    public void setResumoIngles(String resumoIngles) {
        this.resumoIngles = resumoIngles;
    }

    public String getDataEnvioParecer() {
        return dataEnvioParecer;
    }

    public void setDataEnvioParecer(String dataEnvioParecer) {
        this.dataEnvioParecer = dataEnvioParecer;
    }

    public String getDataEmissaoParecer() {
        return dataEmissaoParecer;
    }

    public void setDataEmissaoParecer(String dataEmissaoParecer) {
        this.dataEmissaoParecer = dataEmissaoParecer;
    }

    public String getDescricaoParecer() {
        return descricaoParecer;
    }

    public void setDescricaoParecer(String descricaoParecer) {
        this.descricaoParecer = descricaoParecer;
    }

    public String getStatusParecer() {
        return statusParecer;
    }

    public void setStatusParecer(String statusParecer) {
        this.statusParecer = statusParecer;
    }

    public String getDataDeliberacaoProtocolo() {
        return dataDeliberacaoProtocolo;
    }

    public void setDataDeliberacaoProtocolo(String dataDeliberacaoProtocolo) {
        this.dataDeliberacaoProtocolo = dataDeliberacaoProtocolo;
    }

    public String getStatusDeliberacao() {
        return statusDeliberacao;
    }

    public void setStatusDeliberacao(String statusDeliberacao) {
        this.statusDeliberacao = statusDeliberacao;
    }

    public String getStatusProtocolo() {
        return statusProtocolo;
    }

    public void setStatusProtocolo(String statusProtocolo) {
        this.statusProtocolo = statusProtocolo;
    }
    
    
}
