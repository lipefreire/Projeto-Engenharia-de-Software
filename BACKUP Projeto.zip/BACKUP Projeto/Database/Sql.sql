use projeto;

desc protocolo;

alter table protocolo add column id smallint primary key auto_increment;

select * from protocolo;

desc protocolo;

insert into protocolo 
values (curdate(),curdate(),curdate(),'aaa','sss','ddd',null,null,null,null,null,null,null);